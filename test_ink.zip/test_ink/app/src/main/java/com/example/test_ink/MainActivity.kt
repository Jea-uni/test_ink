package com.example.test_ink

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val arrayAdapter: ArrayAdapter<*>

        val studi = arrayOf(
            "-Shaderland tattoo"
        )
        val stili = arrayOf(
            "-linee fini",
            "-blackwork"
        )

        var studioListView = findViewById<ListView>(R.id.studi_list_lbl)
        arrayAdapter = ArrayAdapter(this,
            android.R.layout.list_content, studi)
        studioListView.adapter = arrayAdapter



    }
}